<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="container mt-5">

            <a href="<?php echo e(route('home')); ?>"> <button class="btn btn-primary"> View products</button> </a>
            <br><br>
            <h2>Cart Details</h2>
    
            <?php if($cartItems->isEmpty()): ?>
                <p>Your cart is empty.</p>
            <?php else: ?>
                <table class="table">
                    <thead>
                        <tr>
                            <th scope="col">Product Name</th>
                            <th scope="col">Price</th>
                            <th scope="col">Quantity</th>
                            <th scope="col">Total Price</th>
                            <th scope="col">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $cartItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($item->product->name); ?></td>
                                <td><?php echo e($item->product->price); ?></td>
                                <td><?php echo e($item->quantity); ?></td>
                                <td> <?php echo e($item->product->price * $item->quantity); ?> </td>
                                <td> <a href="<?php echo e(route('removecart', $item->id)); ?>"> <button class="btn btn-danger">Remove
                                            from cart</button> </a> </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
    
                <p>Total: <?php echo e($total); ?></p>
                <?php if(!$cartItems->isEmpty()): ?>
                    <form action="<?php echo e(route('checkout')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="btn btn-primary">Checkout</button>
                    </form>
                <?php endif; ?>
    
            <?php endif; ?>
        </div>
    
        <!-- Include Bootstrap JS and Popper.js -->
        <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/wmt/Daksh/my tasks/laravel/git/laravel-service-repository/resources/views/user/cart.blade.php ENDPATH**/ ?>