<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Category</title>
    <!-- Include Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
</head>
<body>

<div class="container mt-5">

    <?php if(session('success')): ?>
    <div class="alert alert-success" role="alert">
        <?php echo e(session('success')); ?>

    </div>
<?php endif; ?>
    
    <?php if(isset($cate)): ?> 
    <h2>Edit Category</h2>
    <?php else: ?>
    <h2>Add Category</h2>
    <?php endif; ?>
    <form method="POST" action="<?php echo e(isset($cate) ? route('updatecategory', $cate->id) : route('storecategory')); ?>">
        <?php echo csrf_field(); ?>

        <div class="form-group">
            <label for="name">Category Name:</label>
            <input type="text" class="form-control" id="name" name="name" value="<?php echo e(old('name', $cate->name ?? '')); ?>">
            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <div class="alert alert-danger"><?php echo e($message); ?></div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="form-group">
            <label for="parent_id">Parent Category:</label> 
            <select class="form-control" id="parent_id" name="parent_id">
                <option value="">Select Parent Category</option>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($category->id); ?>"
                        <?php if(isset($cate) && $cate->parent_id == $category->id): ?> selected <?php endif; ?>>
                        <?php echo e($category->name); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>

        </div>

        <button type="submit" class="btn btn-primary">
            <?php if(isset($cate)): ?>
            Edit category
            <?php else: ?>
            Add Category
            <?php endif; ?>
        </button>
    </form>
    <br>
 <a href="<?php echo e(route('viewcategory')); ?>">   <button type="submit" class="btn btn-primary">View Category</button> </a>
</div>

<!-- Include Bootstrap JS and Popper.js -->
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>

</body>
</html>
<?php /**PATH /home/wmt/Daksh/my tasks/laravel/git/laravel-service-repository/resources/views/admin/category.blade.php ENDPATH**/ ?>