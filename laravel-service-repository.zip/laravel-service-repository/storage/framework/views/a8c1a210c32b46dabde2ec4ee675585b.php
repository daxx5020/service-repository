<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
<!-- resources/views/orders/index.blade.php -->

<!-- ... (existing code) ... -->

<div class="container mt-3">
    <a href="<?php echo e(route('home')); ?>"> <button class="btn btn-primary" >Home</button> </a>
    <br> <br>
    <h2>Order Details</h2>

    <?php if($orders->isEmpty()): ?>
        <p>No orders available.</p>
    <?php else: ?>
        <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="card mb-3">
                <div class="card-header">
                    Orders
                </div>
                <div class="card-body">
                    <table class="table">
                        <thead>
                        <tr>
                            <th scope="col">Product Name</th>
                            <th scope="col">Price</th>
                            <th scope="col">Quantity</th>
                            <th scope="col">Total Price</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $order->orderItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $orderItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($orderItem->product->name); ?></td>
                                <td><?php echo e($orderItem->product->price); ?></td>
                                <td><?php echo e($orderItem->quantity); ?></td>
                                <td><?php echo e($orderItem->price); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
</div>

<!-- Include Bootstrap JS and Popper.js -->
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/wmt/Daksh/my tasks/laravel/git/laravel-service-repository/resources/views/user/order.blade.php ENDPATH**/ ?>